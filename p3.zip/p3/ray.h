#ifndef RAY_H
#define RAY_H

#include "vec3.h"

class Ray {
    public:
        Ray() {}
        Ray(const vec3& start, const vec3& dir) : start_(start), dir_(dir) {}
        vec3 start() const { return start_; }
        vec3 dir() const { return dir_; }
        vec3 at(double t) const { return start_ + t * dir_; }
        void set_start(vec3 start) { start_ = start; }
        void set_dir(vec3 dir) { dir_ = dir; }
    private:
        vec3 start_;
        vec3 dir_;
};
#endif // RAY_H