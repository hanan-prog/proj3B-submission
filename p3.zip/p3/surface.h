#ifndef SURFACE_H
#define SURFACE_H

#include "vec3.h"
#include "ray.h"

#include <vector>

class Material;
typedef enum {
    POINT, 
    DIRECTIONAL, 
    SPOT
} light_types;

typedef struct {
    vec3 dir_;
    double angle1, angle2;
} spot_light_t;

typedef struct {
    light_types type;
    spot_light_t spot;
    vec3 pos_;
    Color intensity_;
} light_sources_t; 

struct Record {
    double t;         // distance along the ray where the hit occurred
    vec3 point;    // point of intersection
    vec3 normal;      // surface normal at the intersection, ray is coming from outside the object
    bool n_face; // keeps track of where the normal is facing
    Material *material_ptr; // pointer to the material of the surface hit
    vec3 view_dir; // unit vector points toward the viewer/camera
};

class Surface {
    public:
    virtual ~Surface() = default;
    virtual bool intersect(const Ray &r, double t_min, double t_max, Record &hit_rec) const = 0;
};


// list of surfaces in the scene 
class SurfaceList : public Surface {
    public:
    SurfaceList() = default;
    ~SurfaceList() { clear(); }

    
    void add(Surface *surface) {
        sceneObjects.push_back(surface);
    }

    void add_lights(const light_sources_t& light) {
        lights.push_back(light);
    }

    void clear() {
        // delete every object we own, then clear the list
        for (auto *obj : sceneObjects) {
            delete obj;
        }
        sceneObjects.clear();
    }

    const std::vector<light_sources_t>& get_lights() const { return lights; }

    bool intersect(const Ray &r, double t_min, double t_max, Record &hit_rec) const override {
        Record temp_rec;
        bool hit = false;
        double closest = t_max;

        for (const auto& object : sceneObjects) {
            if (object->intersect(r, t_min, closest, temp_rec)) {
                if (temp_rec.t < closest) {
                    hit = true;
                    closest = temp_rec.t;
                    hit_rec = temp_rec;
                }
            }
        }
        return hit;
    }

    private:
    std::vector<Surface*> sceneObjects;
    std::vector<light_sources_t> lights;
};

#endif // SURFACE_H