#ifndef COLOR_H
#define COLOR_H

#include <stdint.h>
#include "vec3.h"

class Color {
    public:
        double r, g, b;
        Color() : r(0), g(0), b(0) {}
        Color(double red, double green, double blue) : r(red), g(green), b(blue) {}

        Color operator*(const double& f) const {
            return Color(r * f, g * f, b * f);
        }

        Color operator+(const Color& c) const {
            return Color(r + c.r, g + c.g, b + c.b);
        }

        Color operator-(const Color& c) const {
            return Color(r - c.r, g - c.g, b - c.b);
        }

        Color operator+=(const Color& c) {
            r += c.r;
            g += c.g;
            b += c.b;
            return *this;
        }

        bool operator ==(const Color& c) const {
            return (r == c.r && g == c.g && b == c.b);
        }

        Color& Clamp() {
            r = r < 0.0 ? 0.0 : (r > 1.0 ? 1.0 : r);
            g = g < 0.0 ? 0.0 : (g > 1.0 ? 1.0 : g);
            b = b < 0.0 ? 0.0 : (b > 1.0 ? 1.0 : b);
            return *this;
        }
};

inline Color operator*(const Color& c1, const Color& c2) {
    return Color(c1.r * c2.r, c1.g * c2.g, c1.b * c2.b);
}

inline Color operator*(const double& f, const Color& c) {
    return Color(c.r * f, c.g * f, c.b * f);
}

inline Color operator+(const vec3& v, const Color& c) {
    return Color(v.x + c.r, v.y + c.g, v.z + c.b);
}

inline Color operator/(Color c, const double& f) {
    return Color(c.r / f, c.g / f, c.b / f);
}

inline Color calc_intensity(const Color& c, double sqr_dist) {
    return (c * (1 / sqr_dist)).Clamp();
}

#endif