#ifndef TRIANGLE_H
#define TRIANGLE_H


#include "surface.h"
#include "vec3.h"
#include "ray.h"
#include "material.h"



typedef struct {
    double alpha, gamma, beta;
} barycenteric_coord;


class Triangle : public Surface {
    public:
        Triangle(vec3 a, vec3 b, vec3 c, Material *mat_ptr) 
        : t1_(a), t2_(b), t3_(c), material_ptr(mat_ptr) {
            // compute triangle normal from the three vertices
            triangle_normal = cross(t2_ - t1_, t3_ - t1_).normalized();
        }
        Triangle(vec3 t1, vec3 t2, vec3 t3, vec3 n1, vec3 n2, vec3 n3, Material *mat_ptr) 
        : t1_(t1), t2_(t2), t3_(t3), n1_(n1), n2_(n2), n3_(n3), material_ptr(mat_ptr) {}
        ~Triangle() override = default;
        bool intersect(const Ray &ray, double t_min, double t_max, Record &hit_rec) const override {
            // todo: intersection with a triang
            // intersection: e +td= a +β(b−a)+γ(c−a)
            // if p is inside the triangle: beta > 0,  gamma > 0 and beta + gamma < 1
        }

        // calculates the barycenteric coordinate of p 
        barycenteric_coord get_bary_coord(vec3 p, vec3 a, vec3 b, vec3 c) {
            // calculate the barycentric coordinate of point and return 
            barycenteric_coord res; 
            // na = (c−b)×(p−b),
            // nb = (a−c)×(p−c),
            // nc = (b−a)×(p−a).
            // vec3 na = 

            return res;
        }
    
    private:
        vec3 t1_, t2_, t3_; 
        vec3 n1_, n2_, n3_; // normals at each vertex
        vec3 triangle_normal;
        Material *material_ptr;
};
#endif // TRIANGLE_H