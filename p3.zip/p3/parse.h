#ifndef PARSE_H
#define PARSE_H

#include <cstdio>
#include <iostream>
#include <fstream>
#include <cstring>

#include "surface.h"
#include "sphere.h"
#include "material.h"
#include "vec3.h"
#include "color.h"
#include "triangle.h"


// #define DEBUG 1
#define MAX_LINE_LENGTH 500

// parses scene file
Camera& parse(std::string scene_fname, SurfaceList *scene_objects) {
    std::string line;
    std::ifstream fp;
    fp.open(scene_fname);
    Color ambient_color = Color(0.0, 0.0, 0.0);
    Color diffuse_color = Color(1.0, 1.0, 1.0);
    Color specular_color = Color(0.0, 0.0, 0.0);
    int phong_power = 5;
    Color transmissive_color = Color(0.0, 0.0, 0.0);
    double refractive_idx = 1.0;

    // gets updated with "material" command in scene file
    Material *current_material = new Material(
        ambient_color, diffuse_color, specular_color, 
        transmissive_color, refractive_idx, phong_power);
    Camera camera;

    // values to check against once we come normal or vertex
    size_t max_vertices = 0, max_normals = 0;
    
    while (getline(fp, line)) {
        if (line[0] == '#' || line.empty()) {
            continue;
        }

        char tmp[MAX_LINE_LENGTH];
        strncpy(tmp, line.c_str(), sizeof(tmp));
        char* colon = strchr(tmp, ':');

        std::string command;
        if (colon) {
            *colon = '\0';
            char* key = tmp;
            char* values = colon + 1;
            sscanf(key, "%s", command.c_str());
            if(strcmp(command.c_str(), "camera_pos") == 0) {
                double px, py, pz;
                sscanf(values, "%lf %lf %lf", &px, &py, &pz);
                camera.position = vec3(px, py, pz);
            } else if(strcmp(command.c_str(), "camera_fwd") == 0) {
                double dx, dy, dz;
                sscanf(values, "%lf %lf %lf", &dx, &dy, &dz);
                camera.forward = vec3(dx, dy, dz);
            } else if(strcmp(command.c_str(), "camera_up") == 0) {
                double ux, uy, uz;
                sscanf(values, "%lf %lf %lf", &ux, &uy, &uz);
                camera.up = vec3(ux, uy, uz);
            } else if(strcmp(command.c_str(), "camera_fov_ha") == 0) {
                double half_angle_vfov;
                sscanf(values, "%lf", &half_angle_vfov);
                camera.half_angle_vfov = half_angle_vfov;
            } else if (strcmp(command.c_str(), "film_resolution") == 0) {
                int width, height;
                sscanf(values, "%d %d", &width, &height);
                camera.image_width = width;
                camera.image_height = height;
            } else if (strcmp(command.c_str(), "output_image") == 0) {
                char img_fname[256];
                sscanf(values, "%s", img_fname);
                camera.img_fname = std::string(img_fname);
            } else if (strcmp(command.c_str(), "sphere") == 0) {
                // parse sphere
                double x, y, z, radius;
                sscanf(values, "%lf %lf %lf %lf", &x, &y, &z, &radius);
                scene_objects->add(new Sphere(vec3(x, y, z), radius, current_material));
            } else if (strcmp(command.c_str(), "background") == 0) {
                double r, g, b;
                sscanf(values, "%lf %lf %lf", &r, &g, &b);
                camera.set_bg_color(Color(r, g, b));
            } else if (strcmp(command.c_str(), "material") == 0) {
                double ar, ag, ab, dr, dg, db, sr, sg, sb, tr, tg, tb;
                double ior; int ns;
                sscanf(values, "%lf %lf %lf %lf %lf %lf %lf %lf %lf %d %lf %lf %lf %lf", 
                    &ar, &ag, &ab, &dr, &dg, &db, &sr, &sg, &sb, &ns, &tr, &tg, &tb, &ior);
                current_material = new Material(
                    Color(ar, ag, ab), Color(dr, dg, db), 
                    Color(sr, sg, sb), Color(tr, tg, tb), ior, ns);
            } else if (strcmp(command.c_str(), "directional_light") == 0) {
                double dx, dy, dz;
                double r, g, b;
                sscanf(values, "%lf %lf %lf %lf %lf %lf" , &r, &g, &b, &dx, &dy, &dz);
                light_sources_t dir_light;
                dir_light.pos_ = vec3(dx, dy, dz);
                dir_light.intensity_ = Color(r, g, b);
                dir_light.type = DIRECTIONAL;
                scene_objects->add_lights(dir_light);
            } else if (strcmp(command.c_str(), "point_light") == 0) {
                double px, py, pz;
                double r, g, b;
                sscanf(values, "%lf %lf %lf %lf %lf %lf", &r, &g, &b, &px, &py, &pz);
                light_sources_t point_light;
                point_light.pos_ = vec3(px, py, pz);
                point_light.intensity_ = Color(r, g, b);
                point_light.type = POINT;
                scene_objects->add_lights(point_light);
            } else if (strcmp(command.c_str(), "ambient_light") == 0) {
                double r, g, b;
                sscanf(values, "%lf %lf %lf", &r, &g, &b);
                camera.set_ambient_light(Color(r, g, b));
            } else if (strcmp(command.c_str(), "spot_light") == 0) {
                double px, py, pz;
                double dx, dy, dz;
                double angle1, angle2;
                double r, g, b;
                sscanf(values, "%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf", 
                    &r, &g, &b, &px, &py, &pz, &dx, &dy, &dz, &angle1, &angle2);
                light_sources_t spot_l;
                spot_l.intensity_ = Color(r, g, b);
                spot_l.pos_ = vec3(px, py, pz);
                spot_l.type = SPOT;
                spot_l.spot.angle1 = cos(angle1*(M_PI/180.0f));
                spot_l.spot.angle2 = cos(angle2 * (M_PI / 180.0f));
                spot_l.spot.dir_ = vec3(dx, dy, dz);
                scene_objects->add_lights(spot_l);
            } else if(strcmp(command.c_str(), "max_depth") == 0) {
                int max_depth_;
                sscanf(values, "%d", &max_depth_);
                camera.set_max_depth(max_depth_);
            } else if (strcmp(command.c_str(), "max_vertices") == 0) {
                int temp;
                sscanf(values, "%d", &temp);
                max_vertices = temp;
                camera.set_vertices(max_vertices);
            } else if (strcmp(command.c_str(), "max_normals") == 0) {
                int temp;
                sscanf(values, "%d", &temp);
                max_normals = temp;
                camera.set_normals(max_normals);
            } else if (strcmp(command.c_str(), "vertex") == 0){
                if (max_vertices == 0) {
                    printf("Error: 'max_vertices' must be specified before 'vertex' entries.\n");
                    exit(1);
                }
                vec3 vertex;
                sscanf(values, "%lf %lf %lf", &vertex.x, &vertex.y, &vertex.z);
                camera.add_vertex(vertex);
            } else if (strcmp(command.c_str(), "normal") == 0) {
                if (max_normals == 0) {
                    printf("Error: 'max_normals' must be specified before 'normal' entries.\n");
                    exit(1);
                }
                vec3 vertex;
                sscanf(values, "%lf %lf %lf", &vertex.x, &vertex.y, &vertex.z);
                camera.add_normal(vertex);
            } else if (strcmp(command.c_str(), "triangle") == 0) {
                int v1, v2, v3;
                sscanf(values, "%d %d %d", &v1, &v2, &v3);
                vec3 a, b, c; 
                a = camera.get_vertex(v1);
                b = camera.get_vertex(v2);
                c = camera.get_vertex(v3);
               
                scene_objects->add(new Triangle(a, b, c, current_material));
            } else if (strcmp(command.c_str(), "normal_triangle") == 0) {
                int v1, v2, v3, n1, n2, n3;
                sscanf(values, "%d %d %d %d %d %d", &v1, &v2, &v3, &n1, &n2, &n3);
                vec3 a, b, c; 
                a = camera.get_vertex(v1);
                b = camera.get_vertex(v2);
                c = camera.get_vertex(v3);

                vec3 n1_, n2_, n3_;
                n1_ = camera.get_normal(n1);
                n2_ = camera.get_normal(n2);
                n3_ = camera.get_normal(n3);
                scene_objects->add(new Triangle(a, b, c, n1_, n2_, n3_, current_material));
            }    
        }
    }
    return camera;
}

#endif // PARSE_H