



#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS // For fopen and sscanf
#define _USE_MATH_DEFINES 
#endif

//Images Lib includes:
#define STB_IMAGE_IMPLEMENTATION //only place once in one .cpp file
#define STB_IMAGE_WRITE_IMPLEMENTATION //only place once in one .cpp files
#include "image.h" //Image class

#include "surface.h"
#include "sphere.h"
#include "camera.h"

#include "parse.h"


#define DEBUG 1

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cout << "Usage: ./a.out scenefile\n";
        return(0);
    }
    std::string scene_fname = argv[1];

    SurfaceList scene_objects;
    

    int max_depth = 5; // default max depth
    
    Camera camera = parse(scene_fname, &scene_objects);

    // printf("camera viewing from (%lf, %lf, %lf) towards (%lf, %lf, %lf)\n", 
    //     camera.position.x, camera.position.y, camera.position.z,
    //     camera.forward.x, camera.forward.y, camera.forward.z);
   
    camera.render(scene_objects);


    return 0;
}