#ifndef CAMERA_H
#define CAMERA_H

#include "vec3.h"

#include "surface.h"

#include "ray.h"
#include "color.h"
#include "image.h"

#include <chrono>
#include <limits>


// camera parameters and functions

#define DEBUG 1

class Camera {
    public:
    int image_width = 640, image_height = 480; // output image dimensions
    double half_angle_vfov = 45; // half angle of vertical field of view in degrees
    std::string img_fname = "raytraced.bmp"; // output image filename
    vec3 position = vec3(0,0,0);
    vec3 forward = vec3(0,0,-1); // viewing direction
    vec3 up = vec3(0,1,0); // up vector
    int num_samples = 2; // how many samples to take per pixels
    int scale_size = num_samples * num_samples; // how much to scale pixel colors

    void render(const SurfaceList &scene) {
        // initalize viewport/camera parameters
        camera_init();

        // For each pixel in the image
        Image outputImg = Image(image_width, image_height);
        double t_min = -inf, t_max = inf;
        auto t_start = std::chrono::high_resolution_clock::now();
        for (int j = 0; j < image_height; j++) {
            for (int i = 0; i < image_width; i++) {
                Color pixel = sample_pixel(i, j, scene, t_min, t_max);
                outputImg.setPixel(i, j, pixel);
            }
        }

        auto t_end = std::chrono::high_resolution_clock::now();
        printf("Rendering took %.2f ms\n",std::chrono::duration<double, std::milli>(t_end-t_start).count());
        outputImg.write(img_fname.c_str());
    }

    void set_bg_color(const Color& bg) {
        bg_color = bg;
    }

    void set_max_depth(int max_depth) {
        max_depth_ = max_depth;
    }

    void set_ambient_light(const Color& ambient) {
        ambient_light = ambient;
    }

    vec3 get_vertex(int index) {
        // assuming vertices array exists at this point 
        return this->vertices_arr[index];
    }

    vec3 get_normal(int index) {
        // assuming vertices array exists at this point 
        // should prolly add something that does boundry checking
        return this->normal_arr[index];
    }    

    // allocates array to hold our normal vertices
    void set_vertices(size_t max_vertices) {
        this->vertices_arr = (vec3*) malloc(max_vertices * sizeof(vec3));
    }
    
    void set_normals(size_t max_normals) {
        this->normal_arr = (vec3*) malloc(max_normals * sizeof(vec3));
    }

    void add_vertex(vec3 vertex) {
        if (!vertices_arr) {
            // max_vertices hasn't be set
            printf("Error: 'max_vertices' must be specified before 'vertex' entries.\n");
            exit(1);
        }

        vertices_arr[vertex_idx++] = vertex;
    }

    void add_normal(vec3 normal_vertex) {
        if (!normal_arr) {
            printf("Error: 'max_normals' must be specified before 'normal' entries.\n");
            exit(1);
        }
        normal_arr[normal_idx++] = normal_vertex;
    }

    void clear_arr() {
        free(vertices_arr);
        free(normal_arr);
    }
    
    private:
    double inf = std::numeric_limits<double>::infinity();
    Color bg_color = Color(0, 0, 0);
    Color ambient_light = Color(0, 0, 0);
    vec3 u, v, w; // camera coordinate system basis vectors
    vec3 e = vec3(0,0,0); 
    vec3 pixel_u, pixel_v;
    vec3 upper_left_pixel;
    int max_depth_ = 5; 
    int vertex_idx = 0, normal_idx = 0;
    vec3 *vertices_arr = nullptr, *normal_arr = nullptr;


    Color sample_pixel(int i, int j, const SurfaceList &scene, double t_min, double t_max) {
        Color pixel;
        for (int y = 0; y < num_samples; y++) {
            for (int x = 0; x < num_samples; x++) {
                double u = (x + 0.5) / num_samples;
                double v = (y + 0.5) / num_samples;
                vec3 pixel_pos = upper_left_pixel + ((i + u) * pixel_u) + ((j + v)* pixel_v);
                vec3 ray_dir = pixel_pos - e;
                Ray r = Ray(e, ray_dir);
                pixel += ray_trace(r, scene, t_min, t_max, max_depth_);
            }
        }
        pixel =  pixel * (1.0/scale_size);
        return pixel;
    }
    
    void camera_init() {
        // viewport height and width
        double aspect_ratio = double(image_width) / double(image_height);
        w = (forward).normalized(); 
        u = cross(up, w).normalized();        
        v = cross(w, u).normalized();
        e = position;
        // double d = 10.0; // distance from camera to image plane
        double viewport_height = 2.0 * tanf(half_angle_vfov * M_PI / 180.0f);
        double viewport_width = viewport_height * aspect_ratio;
        vec3 viewport_u = viewport_width * -u;    // Vector across viewport horizontal edge
        vec3 viewport_v = viewport_height * -v;  // Vector down viewport vertical edge
        pixel_u = viewport_u / image_width;
        pixel_v = viewport_v / image_height;
        upper_left_pixel =  (e - w - viewport_u/2 - viewport_v/2) + 0.5*(pixel_u + pixel_v);
    }

    Color ray_trace(Ray &r, const SurfaceList &scene, double t_min, double t_max, int max_depth) {
        if (max_depth <= 0) {
            return Color(0, 0, 0);
        }
        Record hit_rec;
        if (scene.intersect(r, t_min, t_max, hit_rec)) {
            return apply_shading(r, hit_rec, scene, max_depth);
        }
        return bg_color; // Return background color
    }

    bool compute_reflection_refraction(Ray& r_in, Ray& r_out, Record const &hit_rec) {
        vec3 ray_dir = r_in.dir().normalized(), normal = hit_rec.normal;
        double refraction_idx = hit_rec.n_face ? (1.0 / hit_rec.material_ptr->get_refractive_idx()) : hit_rec.material_ptr->get_refractive_idx();
        Material *mat_ptr = hit_rec.material_ptr;
        double dot_dn = -dot(ray_dir, normal);
        double pow_ior = refraction_idx * refraction_idx;
        double pow_dn = dot_dn * dot_dn;
        double sign_sqrt = 1 - pow_ior * (1 - pow_dn);

        if (sign_sqrt < 0) {
            return false;
        }
        r_out = Ray(hit_rec.point, refraction_idx * ray_dir + (refraction_idx * dot_dn - sqrt(sign_sqrt)) * normal);
        return true;
    }

    Color apply_shading(Ray &r, Record const &hit_rec, const SurfaceList &scene, int max_depth) {
        Color diffuse, specular, reflected_color, refraction_contribution;
        vec3 normal = hit_rec.normal;

        for (const auto& light : scene.get_lights()) {
            Record shadow_rec;
            Ray shadow_ray = Ray(hit_rec.point, light.pos_ - hit_rec.point);
            if (!scene.intersect(shadow_ray, 0.001, inf, shadow_rec)) {
                vec3 light_dir = (light.pos_ - hit_rec.point).normalized();
                Color intensity = light.intensity_; // default intensity
                if (light.type == POINT) { 
                    // intensity falls off distance squared for point sources
                    intensity = calc_intensity(light.intensity_, (light.pos_ - hit_rec.point).length_squared());  
                }
                
                if (light.type == SPOT) {
                    vec3 spot_dir = light.spot.dir_.normalized();
                    double spot_angle =dot(-light_dir, spot_dir);
                    intensity = calc_intensity(light.intensity_, (light.pos_ - hit_rec.point).length_squared());
                    
                    double falloff = 0.0; 
                    if (spot_angle >= light.spot.angle1) {
                        falloff = 1.0;
                    } else if (spot_angle > light.spot.angle2) {
                        falloff = (spot_angle - light.spot.angle2) / (light.spot.angle1 - light.spot.angle2);
                    }
                    intensity = intensity * falloff;
                }
                // diffuse 
                double dot_nl = fmax(dot(normal, light_dir), 0.0);
                diffuse += (hit_rec.material_ptr->get_diffuse() * intensity * dot_nl);

                // specular
                vec3 reflected_dir = reflect(light_dir, normal);
                double dot_nr = fmax(dot(hit_rec.view_dir, reflected_dir), 0.0);
                double spec = pow(dot_nr, hit_rec.material_ptr->get_phong_power());
                specular += (hit_rec.material_ptr->get_specular() * intensity * spec);
            }
        }

        // we should only trace reflected ray if material has specular component
        Ray reflected_ray = Ray(hit_rec.point, reflect(r.dir(), normal));
        reflected_color = hit_rec.material_ptr->get_specular() * ray_trace(reflected_ray, scene, 0.001, inf, max_depth - 1); 
        
        Ray r_out;
        if(compute_reflection_refraction(r, r_out, hit_rec)){
            // compute refraction
            refraction_contribution = hit_rec.material_ptr->get_transmissive() * ray_trace(r_out, scene, 0.001, inf, max_depth - 1);
        }

       
        double c = fabs(dot(hit_rec.normal, r.dir()));
        double R0 = pow((hit_rec.material_ptr->get_refractive_idx() - 1), 2) / pow((hit_rec.material_ptr->get_refractive_idx() + 1), 2);
        double R1 = R0 + (1.0 - R0) * pow(1.0 - c, 5.0);

        // Combine reflection and refraction
        Color k_tr = R1 * reflected_color + (1.0 - R1) * refraction_contribution;

        Color ambient = ambient_light * hit_rec.material_ptr->get_ambient();
        return ((ambient + diffuse + specular + k_tr + reflected_color)).Clamp();
    }
};

#endif // CAMERA_H