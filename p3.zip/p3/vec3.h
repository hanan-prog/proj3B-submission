#ifndef VEC3_H
#define VEC3_H

#include <cmath>
#include <iostream>



class vec3 {
public:
    double x, y, z;
    vec3() : x(0), y(0), z(0) {}
    vec3(double x, double y, double z) : x(x), y(y), z(z) {}

    vec3 operator-() const
    {
        return vec3(-x, -y, -z);
    }

    double length() const
    {
        return sqrt(length_squared());
    }

    double length_squared() const
    {
        return x * x + y * y + z * z;
    }

    vec3 normalized() const {
        double len = length();
        if (len == 0)  {
            return vec3(0, 0, 0);
        }
        return vec3(x / len, y / len, z / len);
    }

    vec3 &operator*=(double t) {
        x *= t;
        y *= t;
        z *= t;
        return *this;
    }

    vec3& operator/=(double t) {
        return *this *= 1/t;
    }
};

inline std::ostream &operator<<(std::ostream &out, const vec3 &v)
{
    return out << v.x << ' ' << v.y << ' ' << v.z;
}

// addition of two vectors
inline vec3 operator+(const vec3 &u, const vec3 &v)
{
    return vec3(u.x + v.x, u.y + v.y, u.z + v.z);
}

// subtraction of two vectors
inline vec3 operator-(const vec3 &u, const vec3 &v)
{
    return vec3(u.x - v.x, u.y - v.y, u.z - v.z);
}

// multiplication of two vectors
inline vec3 operator*(const vec3 &u, const vec3 &v)
{
    return vec3(u.x * v.x, u.y * v.y, u.z * v.z);
}

inline vec3 operator*(double f, vec3 a)
{
    return vec3(a.x * f, a.y * f, a.z * f);
}

inline vec3 operator*(const vec3 &a, double f)
{
    return f * a;
}

// Vector-vector dot product
inline double dot(vec3 a, vec3 b)
{
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

// Vector-vector cross product
inline vec3 cross(vec3 a, vec3 b)
{
    return vec3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
}

inline vec3 operator/(vec3 v, double t)
{
    return (1 / t) * v;
}

// normalize vector
inline vec3 normalize(vec3 v)
{
    return v / v.length();
}

// reflect vector v around normal n
inline vec3 reflect(const vec3& v, const vec3& n) {
    return v - 2 * dot(v, n) * n;
}

#endif // VEC3_H