#ifndef MATERIAL_H
#define MATERIAL_H


#include "surface.h"
#include "color.h"

// typedef struct {
//     vec3 pos_;
//     Color intensity_;
// } light_t; 

class Material {
    public:
    Material() {}
    ~Material() {}
    
    Material(const Color& ambient_, const Color& diffuse_, const Color& specular_, const Color& transmissive_, double refractive_idx_, int phong_power_)
        : ambient(ambient_), diffuse(diffuse_), specular(specular_), transmissive(transmissive_), refractive_idx(refractive_idx_), phong_power(phong_power_) {}
    


    Color get_specular() { return specular; }
    Color get_ambient() { return ambient; }
    Color get_diffuse() {return diffuse; }
    int get_phong_power() {return phong_power; }
    double get_refractive_idx() { return refractive_idx; }
    Color get_transmissive() { return transmissive; }



    // virtual bool apply_shading(const Ray &ray, const Record &hit_rec, Color &diffuse_color, Ray &reflected_ray) const {
    //     return false;
    // };
   
    
    private:
    Color ambient;
    Color diffuse;
    Color specular;
    Color transmissive;
    double refractive_idx;
    int phong_power;
};

// class LambertianModel : public Material {
//     public:
//     LambertianModel(const Color& color) : color_(color) {}
//     bool apply_shading(const Ray &ray, const Record &hit_rec, Color &diffuse_color, Ray &reflected_ray) override {

//     }
//     private:
//     Color color_;
// }


#endif // MATERIAL_H