#ifndef SPHERE_H
#define SPHERE_H

#include "vec3.h"
#include "ray.h"
#include "material.h"
#include "surface.h"

class Sphere : public Surface {
    public:
    Sphere(const vec3& cen, double radius, Material *mat) : center(cen), r(radius), material_ptr(mat) {}
    
    ~Sphere() override = default;

    bool intersect(const Ray &ray, double t_min, double t_max, Record &hit_rec) const override {
        double a = ray.dir().length_squared();
        vec3 to_start = ray.start() - center;
        double b = 2.0 * dot(ray.dir(), to_start);
        double c = to_start.length_squared() - r * r;

        double discriminant = b * b - 4 * a * c;
        if (discriminant < 0) {
            return false;
        }

        double sqrt_disc = sqrt(discriminant);
        double t1 = (-b - sqrt_disc) / (2.0 * a);
        double t2 = (-b + sqrt_disc) / (2.0 * a);

        double root = t1;
        if (!((t_min < root) && (root < t_max))) {
            root = t2;
            if (!((t_min < root) && (root < t_max))) {
                return false;
            }
        }

        hit_rec.t = root;
        hit_rec.point = ray.at(hit_rec.t);
        vec3 outward_normal = (hit_rec.point - center) / r;
        hit_rec.n_face = dot(ray.dir(), outward_normal) < 0;
        hit_rec.normal = hit_rec.n_face ? outward_normal : -outward_normal;
        hit_rec.material_ptr = material_ptr;
        hit_rec.view_dir = (ray.start() - hit_rec.point).normalized();
        return true;
    };
    private:
    vec3 center;
    double r;
    Material *material_ptr;
};

#endif // SPHERE_H